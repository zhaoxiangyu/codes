package backtype.storm.topology;

import backtype.storm.state.IStateSpout;


public interface IRichStateSpout extends IStateSpout, IComponent {

}
