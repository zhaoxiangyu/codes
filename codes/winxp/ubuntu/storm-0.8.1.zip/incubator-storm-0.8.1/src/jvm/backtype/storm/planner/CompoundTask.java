package backtype.storm.planner;


public class CompoundTask
//        implements IBolt
{

}