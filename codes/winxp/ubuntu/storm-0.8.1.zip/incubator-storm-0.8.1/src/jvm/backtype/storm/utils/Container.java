package backtype.storm.utils;

import java.io.Serializable;

public class Container implements Serializable {
  public Object object;
}