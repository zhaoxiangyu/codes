package storm.trident.operation.impl;

public class Result {
    public Object obj;

    @Override
    public String toString() {
        return "" + obj;
    }    
}
